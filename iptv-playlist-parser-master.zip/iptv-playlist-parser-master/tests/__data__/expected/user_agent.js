export default {
  header: {
    attrs: {},
    raw: '#EXTM3U'
  },
  items: [
    {
      name: 'Agromais',
      tvg: {
        id: 'Agromais.br',
        name: '',
        logo: '',
        url: '',
        rec: '',
        shift: ''
      },
      group: {
        title: 'Entertainment'
      },
      http: {
        referrer: '',
        'user-agent':
          'Mozilla/5.0 (iPhone; CPU iPhone OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148'
      },
      url: 'https://agromais/playlist.m3u8',
      raw: `#EXTINF:-1 tvg-id="Agromais.br" user-agent="Mozilla/5.0 (iPhone; CPU iPhone OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148" group-title="Entertainment",Agromais\r\nhttps://agromais/playlist.m3u8`,
      line: 2,
      timeshift: '',
      catchup: {
        type: '',
        source: '',
        days: ''
      },
      lang: ''
    }
  ]
}
