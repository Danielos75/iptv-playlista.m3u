export default {
  header: {
    attrs: {},
    raw: '#EXTM3U'
  },
  items: [
    {
      name: 'tamazight tv8',
      tvg: {
        id: '',
        name: '',
        logo: '',
        url: '',
        rec: '',
        shift: ''
      },
      group: {
        title: ''
      },
      http: {
        referrer: '',
        'user-agent': ''
      },
      url: 'http://cdn-hls.globecast.tv/live/ramdisk/tamazight_tv8_snrt/hls_snrt/index.m3u8',
      raw: '#EXTINF:-1,tamazight tv8\r\nhttp://cdn-hls.globecast.tv/live/ramdisk/tamazight_tv8_snrt/hls_snrt/index.m3u8',
      line: 3,
      timeshift: '',
      catchup: {
        type: '',
        source: '',
        days: ''
      },
      lang: ''
    }
  ]
}
